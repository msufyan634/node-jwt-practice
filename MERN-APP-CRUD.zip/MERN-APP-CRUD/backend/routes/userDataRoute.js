// const express = require('express')
// const router = express.Router()
// const User = require('../models/userModels')

// //GET all user
// router.get("/", async (req, res) => {
//     try {
//         const allUsers = await User.find();
//         res.status(200).json(allUsers);
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// });

// //GET single user
// router.get("/:id", async (req, res) => {
//     const { id } = req.params
//     try {
//         const singleUser = await User.findOne({ _id: id });
//         res.status(200).json(singleUser);
//     } catch (error) {
//         res.status(500).json({ error: error.message });
//     }
// });

// // Delete user
// router.delete('/:id', async (req, res) => {
//     const { id } = req.params;
//     try {
//         const deleteUser = await User.findByIdAndDelete({ _id: id })
//         res.status(200).json(deleteUser)

//     }
//     catch (error) {
//         res.status(400).json({ error: error.message })
//     }
// })

// //UPDATE
// router.patch("/edit/:id", async (req, res) => {
//     const { id } = req.params;
//     console.log("get body", req.body);
//     console.log("get id", id);
//     try {
//         const updatedUser = await User.findByIdAndUpdate(id, req.body, {
//             new: true,
//         });
//         res.status(200).json(updatedUser);
//     } catch (error) {
//         res.status(400).json({ error: error.message });
//     }
// });



// module.exports = router;


const userController = require("../controller/userController")
module.exports = (app) => {
    app.route("/").get(userController.getAllUser)
    app.route("/createUser").post(userController.createUser)
    app.route("/user/:id").get(userController.getSingleUser)
    app.route("/delete/:id").delete(userController.deleteUser)
    app.route("/update/:id").patch(userController.updateUser)



}