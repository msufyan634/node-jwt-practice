// import { render, screen } from '@testing-library/react';
// import App from './App';

// test('renders learn react link', () => {
//   render(<App />);
//   const linkElement = screen.getByText(/Fill the data/i);
//   expect(linkElement).toBeInTheDocument();
// });


// Counter.test.js
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import CounterTestJest from './test/CounterTestJest';

test('increments the counter', () => {
  render(<CounterTestJest />);

  // Initial count should be 0
  const countElement = screen.getByText(/Count:/);
  expect(countElement).toHaveTextContent('Count: 0');

  // Click the button to increment the count
  const incrementButton = screen.getByText(/Increment/);
  fireEvent.click(incrementButton);

  // After clicking, the count should be 1
  expect(countElement).toHaveTextContent('Count: 1');
});
